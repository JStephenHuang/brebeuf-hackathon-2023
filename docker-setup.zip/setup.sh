#!/bin/bash

docker build -t scraper ./dimg/bookapedia_back/
git clone https://github.com/JStephenHuang/brebeuf-hackathon-2023.git
cp ./dimg/bookapedia_front/Dockerfile ./brebeuf-hackathon-2023/
cp ./dimg/bookapedia_front/vite.config.ts ./brebeuf-hackathon-2023/
mkdir ./common_files
docker build -t react ./brebeuf-hackathon-2023/
docker run --rm scraper /tmp/scraper.py 
docker run -d --rm -p 5173:5173 --name test react

