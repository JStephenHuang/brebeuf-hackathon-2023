#!/bin/python3
import json

with open("list_books_genres.json", "r") as f:
    json_data = json.load(f)
dict_books = json_data 

list_genres = []
for book in dict_books:
    for genre in dict_books[str(book)]["genres"]:
        list_genres.append(genre)
#print(list_genres)
with open("genres.ts", "w") as f:
    print(r"export const genres: string[] = {}".format(list(set(list_genres))), file=f)


