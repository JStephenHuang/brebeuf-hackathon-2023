#!/bin/python3
import cloudscraper
from bs4 import BeautifulSoup
import json

scraper = cloudscraper.create_scraper()

link = r"https://www.nypl.org/books-more/recommendations/125/kids"
html = scraper.get(link).text

#with open("htmlfile.html", "w") as htmlfile:
#    htmlfile.write(html)

#with open("htmlfile.html", "r") as htmlfile:
#    html = htmlfile.read()
soup = BeautifulSoup(html, 'html.parser')

html_list_books = soup.find_all("li", {'class' : "spbb-card spbb-card--grid"})

book_dict = {}

for num, html_book in enumerate(html_list_books):
    book_title = (html_book.find("h4", {'class' : "spbb-card__heading spbb-card__heading--grid"}).text.strip())
    book_link = (html_book.find("a", {'class' : "spbb-card__book-link"})["href"])
    #print(html_book.find("img", {'class' : "spbb-card__image"})["src"])
    if "data" in html_book.find("img")["src"]:
        book_image = (html_book.find("img", {'class' : "spbb-card__image"})["data-src"])
    else:
        book_image = (html_book.find("img", {'class' : "spbb-card__image"})["src"])
#with open("book_list.json", "w") as jsonfile:
#    json.dump(book_dict, jsonfile)

    link = book_link
    html = scraper.get(link).text
    soup = BeautifulSoup(html, 'html.parser')
    
    td_tags = soup.find_all("td")
    all_tags_subject_index = [index for index, tag in enumerate(td_tags) if "Subject" in tag.text]
    all_tags_genre_index = [index for index, tag in enumerate(td_tags) if "Genre/Form" in tag.text]
    
    
    #print(all_tags_subject_index, all_tags_genre_index)
    list1 = []
    for nums in all_tags_subject_index:
        tag_genres = td_tags[nums+1].find_all("a")
        for tag in tag_genres:
            list1.append(tag.text.strip())
    for nums in all_tags_genre_index:
        tag_genres = td_tags[nums+1].find_all("a")
        for tag in tag_genres:
            list1.append(tag.text.strip())
    print(list1)

    book_dict[num] = {"book_title": book_title, "book_link": book_link, "book_image": book_image, "genres": list1}

with open("list-of-books.json", "w") as fp:
    print("\n\n\n\n\n\n\n\nSTARTING JSON DUMP\n\n\n\n\n\n\n")
    json.dump(book_dict, fp)
