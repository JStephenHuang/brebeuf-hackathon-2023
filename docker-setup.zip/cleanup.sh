#!/bin/bash
rm -r brebeuf-hackathon-2023
docker rmi -f react
docker rmi -f scraper
